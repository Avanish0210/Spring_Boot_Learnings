package com.codingshuttle.springboot0To100.hospitalManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HospitalManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
