package com.codingshuttle.springboot0To100.hospitalManagementSystem.dto;

public interface IPatientInfo {

    Long getId();
    String getName();
    String getEmail();
}
